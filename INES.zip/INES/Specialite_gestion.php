<?php
require 'a111.php'; // Database connection

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // Add new spécialité
        $specialite_id = filter_input(INPUT_POST, 'filiere_id', FILTER_VALIDATE_INT);
        $nom_specialite = filter_input(INPUT_POST, 'nom_specialite', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

        try {
            $stmt = $pdo->prepare("INSERT INTO specialites (filiere_id, nom_specialite, description) VALUES (?, ?, ?)");
            $stmt->execute([$specialite_id, $nom_specialite, $description]);
            header('Location: Specialite_gestion.php');
            exit();
        } catch (PDOException $e) {
            $error = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    } elseif (isset($_POST['delete'])) {
        // Delete spécialité
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

        if ($id) {
            try {
                $stmt = $pdo->prepare("DELETE FROM specialites WHERE id = ?");
                $stmt->execute([$id]);
                header('Location: Specialite_gestion.php');
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la suppression : " . $e->getMessage();
            }
        }
    } elseif (isset($_POST['update'])) {
        // Update spécialité
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $specialite_id = filter_input(INPUT_POST, 'filiere_id', FILTER_VALIDATE_INT);
        $nom_specialite = filter_input(INPUT_POST, 'nom_specialite', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

        if ($id) {
            try {
                $stmt = $pdo->prepare("UPDATE specialites SET filiere_id = ?, nom_specialite = ?, description = ? WHERE id = ?");
                $stmt->execute([$specialite_id, $nom_specialite, $description, $id]);
                header('Location: Specialite_gestion.php');
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la mise à jour : " . $e->getMessage();
            }
        }
    }
}

// Fetch data
try {
    // Get all filières for dropdown
    $specialites = $pdo->query("SELECT * FROM filieres ORDER BY nom_filiere")->fetchAll(PDO::FETCH_ASSOC);

    // Get specialités with filière names
    $stmt = $pdo->query("
        SELECT s.*, f.nom_filiere 
        FROM specialites s
        JOIN filieres f ON s.filiere_id = f.id
        ORDER BY f.nom_filiere, s.nom_specialite
    ");
    $specialites = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching data: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Spécialités</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/sidebar2.css">
    <link rel="stylesheet" href="css/table_de_gestion.css">
    <link rel="stylesheet" href="css/gestion_des_memoires.css">
    <link rel="stylesheet" href="css/filiere.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <?php include 'header.html' ?>
    </header>
    <div class="wrapper">
        <?php include 'html/Admin_sidebar.html'; ?>
        <div class="main-content">

            <h1 class="stylish-title">
                <i class="fas fa-cog"></i>
                Gestion des Spécialités
            </h1>


            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <!-- Add Form -->

            <div class="gradient-title">Ajouter une Spécialité</div>

            <form method="POST">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="filiere">Nom de la Filière</label>
                            <select class="form-select" name="filiere_id" required>
                                <?php foreach ($specialites as $specialite): ?>
                                    <option value="<?= $specialite['id'] ?>"><?= htmlspecialchars($specialite['nom_filiere']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="specialite">Nom de la Spécialité</label>
                            <input type="text" class="form-control" name="nom_specialite" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea type="text" class="form-control" name="description"></textarea>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <button type="submit" name="add" class="btn btn-primary mt-4">Ajouter</button>
                    </div>
                </div>
            </form>


            <!-- Specialités Table -->

            <div class="gradient-title">Table des Spécialités</div>

            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Filière</th>
                            <th>Spécialité</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($specialites as $specialite): ?>
                            <tr>
                                <td><?= htmlspecialchars($specialite['nom_filiere']) ?></td>
                                <td><?= htmlspecialchars($specialite['nom_specialite']) ?></td>
                                <td><?= htmlspecialchars($specialite['description']) ?></td>
                                <td class="action-buttons">
                                    <!-- Edit Button -->
                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                        data-bs-target="#editModal<?= $specialite['id'] ?>">
                                        <i class="fas fa-edit"></i>

                                    </button>

                                    <!-- Delete Form -->
                                    <form method="post" style="display:inline;">
                                        <input type="hidden" name="id" value="<?= $specialite['id'] ?>">
                                       <button type="submit" name="delete" class="btn btn-danger">
                                            <i class="fas fa-trash-alt"></i>

                                        </button>
                                    </form>

                                    <!-- Edit Modal -->
                                    <div class="modal fade" id="editModal<?= $specialite['id'] ?>" tabindex="-1"
                                        aria-labelledby="editModalLabel<?= $specialite['id'] ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg">
                                                <div class="modal-header text-white">
                                                    <h5 class="modal-title fs-5">
                                                        <i class="bi bi-pencil-square me-2"></i>
                                                        Modifier Specialite #<?= $specialite['id'] ?>
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white"
                                                        data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post">
                                                    <div class="modal-body p-4">
                                                        <input type="hidden" name="id" value="<?= $specialite['id'] ?>">

                                                        <div class="mb-3">
                                                            <label class="form-label">
                                                                <i class="bi bi-tag-fill text-primary me-2"></i>
                                                                Filière</label>
                                                            <select class="form-select" name="filiere_id" required>
                                                                <?php foreach ($specialites as $specialite): ?>
                                                                    <option value="<?= $specialite['id'] ?>"
                                                                        <?= $specialite['id'] == $specialite['filiere_id'] ? 'selected' : '' ?>>
                                                                        <?= htmlspecialchars($specialite['nom_filiere']) ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="form-label">
                                                                <i class="bi bi-tag-fill text-primary me-2"></i>
                                                                Nom de la Spécialité</label>
                                                            <input type="text" class="form-control"
                                                                name="nom_specialite"
                                                                value="<?= htmlspecialchars($specialite['nom_specialite']) ?>" required>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="form-label">
                                                                <i class="bi bi-text-paragraph text-primary me-2"></i>
                                                                Description</label>
                                                            <input type="text" class="form-control"
                                                                name="description"
                                                                value="<?= htmlspecialchars($specialite['description']) ?>">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer bg-light">
                                                        <button type="button" class="btn btn-outline-secondary"
                                                            data-bs-dismiss="modal">
                                                            <i class="bi bi-x-circle me-2"></i>
                                                            Annuler
                                                        </button>
                                                        <button type="submit" name="update" class="btn btn-ok">
                                                            <i class="bi bi-check-circle me-2"></i>
                                                            Enregistrer
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/sidebar.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
</body>

</html>