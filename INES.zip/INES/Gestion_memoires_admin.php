<?php

// Connexion à la base de données
$db = new PDO('mysql:host=localhost;dbname=pfe;charset=utf8', 'root', '');

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['memoire_id']) && isset($_POST['action'])) {
        $memoire_id = intval($_POST['memoire_id']);
        $new_status = ($_POST['action'] === 'accept') ? 'accepter' : 'refuser';

        // Requête préparée pour la mise à jour
        $stmt = $db->prepare("UPDATE memoires 
                                SET status = ?, date_edition = NOW() 
                                WHERE id = ?");
        $stmt->execute([$new_status, $memoire_id]);

        // Redirection pour éviter le rechargement
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Récupération des mémoires en attente avec jointures
$query = $db->query("
        SELECT m.*, f.nom_filiere, s.nom_specialite 
        FROM memoires m
        LEFT JOIN filieres f ON m.filiere = f.id
        LEFT JOIN specialites s ON m.specialite = s.id
        WHERE m.status = 'en_attente'
    ");
$memoires = $query->fetchAll(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/sidebar2.css">
    <link rel="stylesheet" href="css/table_de_gestion.css">
    <link rel="stylesheet" href="css/gestion_des_memoires.css">
    <link rel="stylesheet" href="style.css">

    <title>Gestion des Memoires administrateur</title>
</head>

<body>
    <header>
        <?php include 'header.html' ?>
    </header>
    <div class="wrapper">

        <?php
        include 'html/Admin_sidebar.html';
        // include 'table_de_gestion_memoires.php';
        ?>
        <div class="main-content">
            <div class="card" style="width: 100%;">
                <div class="card-body">
                    <div class="card-header">
                        <h1>Gestion des Mémoires de Thèse</h1>
                    </div>

                    <div class="table-responsive">
                        <br>

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Titre</th>
                                    <th>Auteur</th>
                                    <th>Filière</th>
                                    <th>Spécialité</th>
                                    <th>Date dépôt</th>
                                    <th>Memoire</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($memoires as $memoire): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($memoire['titre']) ?></td>
                                        <td><?= htmlspecialchars($memoire['auteur']) ?></td>
                                        <td><?= htmlspecialchars($memoire['nom_filiere']) ?></td>
                                        <td><?= htmlspecialchars($memoire['nom_specialite']) ?></td>
                                        <td><?= $memoire['date_ajout'] ?></td>
                                        <td><!--to be changed-->
                                            <a href="uploads/<?= htmlspecialchars($memoire['fichier_pdf']) ?>"
                                                class="pdf-link"
                                                target="_blank"
                                                title="Voir le PDF">
                                                <i class="fas fa-file-pdf"></i>
                                            </a>
                                        </td>
                                        <td class="action-buttons">
                                            <div class="btn-group">
                                                <form method="post" style="display: inline;">
                                                    <input type="hidden" name="memoire_id" value="<?= $memoire['id'] ?>"> <!-- Corrected field name -->
                                                    <button type="submit" name="action" value="accept" class="btn btn-success btn-sm">
                                                        <i class="fas fa-check"></i>
                                                    </button>

                                                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <a href="a1111.php" class="add-livre">
                        <i class="fas fa-plus"></i> Ajouter un Livre
                    </a>

                </div>
            </div>
        </div>
    </div>
    <!-- Load all JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/sidebar.js"> </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
</body>

</html>