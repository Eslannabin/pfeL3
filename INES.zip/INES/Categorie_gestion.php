<?php
require 'a111.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // Add new category with specific ID if available
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $nom = filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

        try {
            if ($id) {
                // Try to insert with specific ID
                $stmt = $pdo->prepare("INSERT INTO categories (id, nom, description) VALUES (?, ?, ?)");
                $stmt->execute([$id, $nom, $description]);
            } else {
                // Auto-increment if no ID specified
                $stmt = $pdo->prepare("INSERT INTO categories (nom, description) VALUES (?, ?)");
                $stmt->execute([$nom, $description]);
            }
            header('Location: Categorie_gestion.php');
            exit();
        } catch (PDOException $e) {
            $error = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    } elseif (isset($_POST['delete'])) {
        // Delete category
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

        if ($id) {
            try {
                $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
                $stmt->execute([$id]);
                header('Location: Categorie_gestion.php');
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la suppression : " . $e->getMessage();
            }
        }
    } elseif (isset($_POST['update'])) {
        // Update category
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $nom = filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

        if ($id) {
            try {
                $stmt = $pdo->prepare("UPDATE categories SET nom = ?, description = ? WHERE id = ?");
                $stmt->execute([$nom, $description, $id]);
                header('Location: Categorie_gestion.php');
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la mise à jour : " . $e->getMessage();
            }
        }
    }
}

// Fetch all categories
try {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY id");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get available IDs (gaps in sequence)
    $stmt = $pdo->query("SELECT t1.id + 1 AS missing_id
                         FROM categories t1
                         LEFT JOIN categories t2 ON t1.id + 1 = t2.id
                         WHERE t2.id IS NULL AND t1.id < (SELECT MAX(id) FROM categories)");
    $available_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Also check if 1 is available
    $stmt = $pdo->query("SELECT 1 AS missing_id WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 1)");
    $first_id = $stmt->fetchColumn();
    if ($first_id) {
        array_unshift($available_ids, $first_id);
    }
} catch (PDOException $e) {
    die("Error fetching categories: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/sidebar2.css">
    <link rel="stylesheet" href="css/table_de_gestion.css">
    <link rel="stylesheet" href="css/gestion_des_memoires.css">
    <link rel="stylesheet" href="style.css">

    <title>Gestion des Categories</title>

    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .table-responsive {
            overflow-x: auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .action-buttons {
            white-space: nowrap;
        }

        .available-id {
            cursor: pointer;
        }

        .available-id:hover {
            background-color: #e9ecef;
        }

        /* Modal enhancements */
        .modal-content {
            border-radius: 15px;
            overflow: hidden;
        }

        .modal-header {
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }

        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.05);
        }

        .form-control-lg {
            padding: 0.75rem 1rem;
            font-size: 1.05rem;
        }

        .rounded-pill {
            padding: 0.5rem 1.5rem;
        }
    </style>
</head>

<body>
    <header>
        <?php include 'header.html' ?>
    </header>
    <div class="wrapper">

        <?php
        include 'html/Admin_sidebar.html';
        ?>

        <div class="container">
            <h1 class="text-center mb-4">Gestion des Catégories</h1>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?= $error ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div> 
            <?php endif; ?>

            <!-- Add Category Form -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Ajouter une Nouvelle Catégorie</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="id">ID (optionnel)</label>
                                    <input type="number" class="form-control" id="id" name="id" min="1"
                                        placeholder="Laisser vide pour auto-incrément">
                                    <?php if (!empty($available_ids)): ?>
                                        <small class="text-muted">IDs disponibles:
                                            <?php foreach ($available_ids as $avail_id): ?>
                                                <span class="available-id" onclick="document.getElementById('id').value=<?= $avail_id ?>">
                                                    <?= $avail_id ?>
                                                </span>
                                            <?php endforeach; ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="nom">Nom de la catégorie</label>
                                    <input type="text" class="form-control" id="nom" name="nom" required>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <input type="text" class="form-control" id="description" name="description">
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="add" class="btn btn-primary mt-2">Ajouter</button>
                    </form>
                </div>
            </div>

            <!-- Categories Table -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Liste des Catégories</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nom</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categories as $index => $category): ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td> <!-- Row number -->
                                        <td><?= htmlspecialchars($category['nom']) ?></td>
                                        <td><?= htmlspecialchars($category['description']) ?></td>
                                        <td class="action-buttons">
                                            <!-- Edit Button (triggers modal) -->
                                            <button type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                                                data-bs-target="#editModal<?= $category['id'] ?>">
                                                Modifier
                                            </button>

                                            <!-- Delete Form -->
                                            <form method="post" style="display:inline;">
                                                <input type="hidden" name="id" value="<?= $category['id'] ?>">
                                                <button type="submit" name="delete" class="btn btn-sm btn-danger">
                                                    Supprimer
                                                </button>
                                            </form>

                                            <!-- Edit Modal -->
                                            <div class="modal fade" id="editModal<?= $category['id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $category['id'] ?>" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content border-0 shadow-lg">
                                                        <div class="modal-header bg-primary text-white">
                                                            <h5 class="modal-title fs-5" id="editModalLabel<?= $category['id'] ?>">
                                                                <i class="bi bi-pencil-square me-2"></i>
                                                                Modifier Catégorie #<?= $index +1 ?>
                                                            </h5>
                                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form method="post">
                                                            <div class="modal-body p-4">
                                                                <input type="hidden" name="id" value="<?= $category['id'] ?>">

                                                                <div class="mb-4">
                                                                    <label for="nom<?= $category['id'] ?>" class="form-label fw-bold">
                                                                        <i class="bi bi-tag-fill text-primary me-2"></i>
                                                                        Nom de la catégorie
                                                                    </label>
                                                                    <input type="text" class="form-control form-control-lg border-2 border-primary"
                                                                        id="nom<?= $category['id'] ?>" name="nom"
                                                                        value="<?= htmlspecialchars($category['nom']) ?>" required>
                                                                    <div class="form-text">Modifier le nom de cette catégorie</div>
                                                                </div>

                                                                <div class="mb-3">
                                                                    <label for="description<?= $category['id'] ?>" class="form-label fw-bold">
                                                                        <i class="bi bi-text-paragraph text-primary me-2"></i>
                                                                        Description
                                                                    </label>
                                                                    <textarea class="form-control border-2 border-primary" id="description<?= $category['id'] ?>"
                                                                        name="description" rows="3"><?= htmlspecialchars($category['description']) ?></textarea>
                                                                    <div class="form-text">Ajoutez une description détaillée</div>
                                                                </div>
                                                            </div>

                                                            <div class="modal-footer bg-light">
                                                                <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">
                                                                    <i class="bi bi-x-circle me-2"></i>
                                                                    Annuler
                                                                </button>
                                                                <button type="submit" name="update" class="btn btn-primary rounded-pill px-4">
                                                                    <i class="bi bi-check-circle me-2"></i>
                                                                    Enregistrer
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Load all JS -->
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/sidebar.js"> </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
</body>

</html>