<?php
session_start();
require 'a111.php'; // Database connection

$error = '';
$success = '';

// Get related data
try {
    $filieres = $pdo->query("SELECT * FROM filieres")->fetchAll(PDO::FETCH_ASSOC);
    $specialites = $pdo->query("SELECT * FROM specialites")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching data: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate required fields
        $required = ['universite', 'filiere', 'specialite', 'diplome', 'titre', 'encadreur', 'auteur', 'annee', 'resume'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Le champ " . ucfirst($field) . " est obligatoire");
            }
        }

        // File handling
        $pdfPath = '';
        $imagePath = '';

        // Handle PDF upload
        if (isset($_FILES['fichier_pdf']) && $_FILES['fichier_pdf']['error'] === UPLOAD_ERR_OK) {
            $pdfDir = 'uploads/pdf/';
            if (!is_dir($pdfDir)) mkdir($pdfDir, 0755, true);
            
            $pdfExt = pathinfo($_FILES['fichier_pdf']['name'], PATHINFO_EXTENSION);
            $pdfFilename = uniqid('memoire_') . '.' . $pdfExt;
            $pdfPath = $pdfDir . $pdfFilename;
            
            if (!move_uploaded_file($_FILES['fichier_pdf']['tmp_name'], $pdfPath)) {
                throw new Exception("Erreur lors du téléchargement du fichier PDF");
            }
        } else {
            throw new Exception("Le fichier PDF est obligatoire");
        }

        // Handle image upload
        if (isset($_FILES['image_path']) && $_FILES['image_path']['error'] === UPLOAD_ERR_OK) {
            $imageDir = 'uploads/images/';
            if (!is_dir($imageDir)) mkdir($imageDir, 0755, true);
            
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            $fileType = mime_content_type($_FILES['image_path']['tmp_name']);
            
            if (!in_array($fileType, $allowedTypes)) {
                throw new Exception("Seuls les fichiers JPG, PNG et GIF sont autorisés pour l'image");
            }
            
            $imageExt = pathinfo($_FILES['image_path']['name'], PATHINFO_EXTENSION);
            $imageFilename = uniqid('cover_') . '.' . $imageExt;
            $imagePath = $imageDir . $imageFilename;
            
            if (!move_uploaded_file($_FILES['image_path']['tmp_name'], $imagePath)) {
                throw new Exception("Erreur lors du téléchargement de l'image");
            }
        }

        // Get user ID from session
        $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

        // Insert into database
        $stmt = $pdo->prepare("
            INSERT INTO memoires (
                universite, filiere, specialite, diplome, titre,
                encadreur, auteur, annee, resume, fichier_pdf,
                image_path, status, id_utilisateur
            ) VALUES (
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?
            )
        ");

        $stmt->execute([
            $_POST['universite'],
            $_POST['filiere'],
            $_POST['specialite'],
            $_POST['diplome'],
            $_POST['titre'],
            $_POST['encadreur'],
            $_POST['auteur'],
            $_POST['annee'],
            $_POST['resume'],
            $pdfPath,
            $imagePath,
            $_POST['status'] ?? 'en_attente',
            $userId
        ]);

        $success = "Mémoire ajouté avec succès!";
    } catch (Exception $e) {
        $error = "Erreur : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout de Mémoire</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .required::after { content: "*"; color: red; margin-left: 3px; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Ajouter un Mémoire</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="row g-3">
                <!-- University and Relationships -->
                <div class="col-md-6">
                    <label class="form-label required">Université</label>
                    <input type="text" class="form-control" name="universite" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label required">Filière</label>
                    <select class="form-select" name="filiere" required>
                        <option value="">Choisir une filière</option>
                        <?php foreach ($filieres as $filiere): ?>
                            <option value="<?= $filiere['id'] ?>"><?= htmlspecialchars($filiere['nom_filiere']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label required">Spécialité</label>
                    <select class="form-select" name="specialite" required>
                        <option value="">Choisir une spécialité</option>
                        <?php foreach ($specialites as $specialite): ?>
                            <option value="<?= $specialite['id'] ?>"><?= htmlspecialchars($specialite['nom_specialite']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Thesis Details -->
                <div class="col-md-6">
                    <label class="form-label required">Diplôme</label>
                    <select class="form-select" name="diplome" required>
                        <option value="doctorat">Doctorat</option>
                        <option value="master">Master</option>
                        <option value="licence">Licence</option>
                    </select>
                </div>

                <div class="col-12">
                    <label class="form-label required">Titre</label>
                    <input type="text" class="form-control" name="titre" required>
                </div>

                <!-- People Involved -->
                <div class="col-md-6">
                    <label class="form-label required">Encadreur</label>
                    <input type="text" class="form-control" name="encadreur" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label required">Auteur</label>
                    <input type="text" class="form-control" name="auteur" required>
                </div>

                <!-- Year and Status -->
                <div class="col-md-6">
                    <label class="form-label required">Année</label>
                    <input type="number" class="form-control" name="annee" 
                           min="1900" max="<?= date('Y') ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Statut</label>
                    <select class="form-select" name="status">
                        <option value="en_attente">En attente</option>
                        <option value="accepter">Accepté</option>
                        <option value="refuser">Refusé</option>
                    </select>
                </div>

                <!-- Abstract -->
                <div class="col-12">
                    <label class="form-label required">Résumé</label>
                    <textarea class="form-control" name="resume" rows="4" required></textarea>
                </div>

                <!-- File Uploads -->
                <div class="col-md-6">
                    <label class="form-label required">Fichier PDF</label>
                    <input type="file" class="form-control" name="fichier_pdf" accept=".pdf" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Image de couverture</label>
                    <input type="file" class="form-control" name="image_path" accept="image/*">
                </div>

                <!-- Submit Button -->
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Ajouter le Mémoire</button>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>