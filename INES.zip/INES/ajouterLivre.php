<?php
// Configuration de la base de données
require_once 'a111.php';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    $uploadDir = __DIR__ . '/uploads/';

    // Validation des champs
    $requiredFields = [
        'titre', 'auteur', 'description', 
        'mots_cles', 'annee_publication', 'nombre_pages'
    ];
    
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            $errors[] = "Le champ $field est obligatoire";
        }
    }

    // Vérification des fichiers
    $allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $fileTypes = [
        'image' => [
            'file' => $_FILES['image'],
            'allowed' => $allowedImageTypes,
            'max_size' => 2 * 1024 * 1024 // 2MB
        ],
        'pdf' => [
            'file' => $_FILES['fichier_pdf'],
            'allowed' => ['application/pdf'],
            'max_size' => 5 * 1024 * 1024 // 5MB
        ]
    ];

    foreach ($fileTypes as $type => $info) {
        if ($info['file']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Erreur lors de l'upload du fichier $type";
            continue;
        }

        if ($info['file']['size'] > $info['max_size']) {
            $errors[] = "Le fichier $type est trop volumineux";
        }

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($info['file']['tmp_name']);
        
        if (!in_array($mime, $info['allowed'])) {
            $errors[] = "Type de fichier $type non autorisé";
        }
    }

    // Si pas d'erreurs, traitement
    if (empty($errors)) {
        try {
            // Déplacement des fichiers
            $imageName = uniqid() . '_' . basename($_FILES['image']['name']);
            $pdfName = uniqid() . '_' . basename($_FILES['fichier_pdf']['name']);
            
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
            move_uploaded_file($_FILES['fichier_pdf']['tmp_name'], $uploadDir . $pdfName);

            // Insertion en base
            $stmt = $pdo->prepare("
                INSERT INTO livre (
                    titre, auteur, description, image, categories_id,
                    mots_cles, fichier_pdf, annee_publication,
                    nombre_pages, id_utilisateur
                ) VALUES (
                    :titre, :auteur, :description, :image, :categories_id,
                    :mots_cles, :fichier_pdf, :annee_publication,
                    :nombre_pages, :id_utilisateur
                )
            ");

            $data = [
                ':titre' => htmlspecialchars($_POST['titre']),
                ':auteur' => htmlspecialchars($_POST['auteur']),
                ':description' => htmlspecialchars($_POST['description']),
                ':image' => $imageName,
                ':categories_id' => $_POST['categories_id'] ?: null,
                ':mots_cles' => htmlspecialchars($_POST['mots_cles']),
                ':fichier_pdf' => $pdfName,
                ':annee_publication' => (int)$_POST['annee_publication'],
                ':nombre_pages' => (int)$_POST['nombre_pages'],
                ':id_utilisateur' => 1 // À remplacer par l'ID de session
            ];

            $stmt->execute($data);
            $success = "Livre ajouté avec succès !";
            
        } catch(PDOException $e) {
            $errors[] = "Erreur base de données : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un livre</title>
    <style>
        .container { max-width: 800px; margin: 20px auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { 
            width: 100%; 
            padding: 8px; 
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button { 
            padding: 10px 20px; 
            background: #4CAF50; 
            color: white; 
            border: none; 
            border-radius: 4px;
            cursor: pointer;
        }
        .error { color: red; margin-bottom: 15px; }
        .success { color: green; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Ajouter un nouveau livre</h2>

        <?php if (!empty($errors)): ?>
            <div class="error">
                <?php foreach ($errors as $error): ?>
                    <p><?= $error ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <!-- Titre -->
            <div class="form-group">
                <label for="titre">Titre*</label>
                <input type="text" id="titre" name="titre" required>
            </div>

            <!-- Auteur -->
            <div class="form-group">
                <label for="auteur">Auteur*</label>
                <input type="text" id="auteur" name="auteur" required>
            </div>

            <!-- Description -->
            <div class="form-group">
                <label for="description">Description*</label>
                <textarea id="description" name="description" rows="4" required></textarea>
            </div>

            <!-- Image -->
            <div class="form-group">
                <label for="image">Couverture (JPEG/PNG/GIF - max 2MB)*</label>
                <input type="file" id="image" name="image" accept="image/*" required>
            </div>

            <!-- Catégorie -->
            <div class="form-group">
                <label for="categories_id">Catégorie</label>
                <select id="categories_id" name="categories_id">
                    <option value="">-- Sélectionner --</option>
                    <?php
                    $categories = $pdo->query("SELECT id, nom FROM categories");
                    while($cat = $categories->fetch(PDO::FETCH_ASSOC)): ?>
                        <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nom']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <!-- Mots-clés -->
            <div class="form-group">
                <label for="mots_cles">Mots-clés (séparés par des virgules)*</label>
                <input type="text" id="mots_cles" name="mots_cles" required>
            </div>

            <!-- PDF -->
            <div class="form-group">
                <label for="fichier_pdf">Fichier PDF (max 5MB)*</label>
                <input type="file" id="fichier_pdf" name="fichier_pdf" accept="application/pdf" required>
            </div>

            <!-- Année -->
            <div class="form-group">
                <label for="annee_publication">Année de publication*</label>
                <input type="number" id="annee_publication" name="annee_publication" 
                       min="1900" max="<?= date('Y') ?>" required>
            </div>

            <!-- Pages -->
            <div class="form-group">
                <label for="nombre_pages">Nombre de pages*</label>
                <input type="number" id="nombre_pages" name="nombre_pages" min="1" required>
            </div>

            <button type="submit">Ajouter le livre</button>
        </form>
    </div>
</body>
</html>