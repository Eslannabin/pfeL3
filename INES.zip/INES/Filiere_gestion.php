<?php
require 'a111.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // Add new filiere
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $nom_filiere = filter_input(INPUT_POST, 'nom_filiere');
        $description = filter_input(INPUT_POST, 'description');

        try {
            if ($id) {
                $stmt = $pdo->prepare("INSERT INTO filieres (id, nom_filiere, description) VALUES (?, ?, ?)");
                $stmt->execute([$id, $nom_filiere, $description]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO filieres (nom_filiere, description) VALUES (?, ?)");
                $stmt->execute([$nom_filiere, $description]);
            }
            header('Location: Filiere_gestion.php');
            exit();
        } catch (PDOException $e) {
            $error = "Erreur lors de l'ajout , cle duplique '2' ";
        }
    } elseif (isset($_POST['delete'])) {
        // Delete filiere
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

        if ($id) {
            try {
                $stmt = $pdo->prepare("DELETE FROM filieres WHERE id = ?");
                $stmt->execute([$id]);
                header('Location: Filiere_gestion.php');
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la suppression : " . $e->getMessage();
            }
        }
    } elseif (isset($_POST['update'])) {
        // Update filiere
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $nom_filiere = filter_input(INPUT_POST, 'nom_filiere');
        $description = filter_input(INPUT_POST, 'description');

        if ($id) {
            try {
                $stmt = $pdo->prepare("UPDATE filieres SET nom_filiere = ?, description = ? WHERE id = ?");
                $stmt->execute([$nom_filiere, $description, $id]);
                header('Location: Filiere_gestion.php');
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la mise à jour : " . $e->getMessage();
            }
        }
    }
}

// Fetch all filieres and available IDs
try {
    // Get filieres
    $stmt = $pdo->query("SELECT * FROM filieres ORDER BY id");
    $filieres = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get available IDs
    $stmt = $pdo->query("SELECT t1.id + 1 AS missing_id
                        FROM filieres t1
                        LEFT JOIN filieres t2 ON t1.id + 1 = t2.id
                        WHERE t2.id IS NULL AND t1.id < (SELECT MAX(id) FROM filieres)
                        UNION
                        SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM filieres WHERE id = 1)");
    $available_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die("Error fetching filieres: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/sidebar2.css">
    <link rel="stylesheet" href="css/table_de_gestion.css">
    <link rel="stylesheet" href="css/gestion_des_memoires.css">
    <link rel="stylesheet" href="css/filiere.css">
    <link rel="stylesheet" href="style.css">
    <title>Gestion des filieres</title>


</head>

<body>
    <header>
        <?php include 'header.html' ?>
    </header>
    <div class="wrapper">
        <?php include 'html/Admin_sidebar.html'; ?>

        <div class="main-content">


            <h1 class="stylish-title"> <i class="fas fa-cog me-2"></i>Gestion des Filieres</h1>


            <?php if (isset($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?= $error ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Add Form -->
            <div class="gradient-title">Ajouter une Filiere</div>
            <form method="post">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="id">ID (optionnel)</label>
                            <input type="number" class="form-control" id="id" name="id" min="1"
                                placeholder="Auto-incrément">
                            <?php if (!empty($available_ids)): ?>
                                <small class="text-muted">IDs disponibles:
                                    <?php foreach ($available_ids as $avail_id): ?>
                                        <span class="available-id" onclick="document.getElementById('id').value=<?= $avail_id ?>">
                                            <?= $avail_id ?>
                                        </span>
                                    <?php endforeach; ?>
                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="nom_filiere">Nom de la Filiere</label>
                            <input type="text" class="form-control" id="nom_filiere" name="nom_filiere" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea type="text" class="form-control" id="description" name="description" required></textarea>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <button type="submit" name="add" class="btn btn-primary mt-4">Ajouter</button>
                    </div>
                </div>
            </form>

            <!-- Table -->
            <div class="gradient-title">Tableau des Filieres</div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($filieres as $index => $filiere): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($filiere['nom_filiere']) ?></td>
                                <td><?= htmlspecialchars($filiere['description']) ?></td>
                                <td class="action-buttons">
                                    <!-- Edit Button -->
                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                        data-bs-target="#editModal<?= $filiere['id'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>

                                    <!-- Delete Form -->
                                    <form method="post" style="display:inline;">
                                        <input type="hidden" name="id" value="<?= $filiere['id'] ?>">
                                        <button type="submit" name="delete" class="btn btn-danger">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>

                                    <!-- Edit Modal -->
                                    <div class="modal fade" id="editModal<?= $filiere['id'] ?>" tabindex="-1"
                                        aria-labelledby="editModalLabel<?= $filiere['id'] ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg">
                                                <div class="modal-header text-white">
                                                    <h5 class="modal-title fs-5">
                                                        <i class="bi bi-pencil-square me-2"></i>
                                                        Modifier Filiere #<?= $filiere['id'] ?>
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white"
                                                        data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post">
                                                    <div class="modal-body p-4">
                                                        <input type="hidden" name="id" value="<?= $filiere['id'] ?>">

                                                        <div class="mb-4">
                                                            <label class="form-label fw-bold">
                                                                <i class="bi bi-tag-fill text-primary me-2"></i>
                                                                Nom de la Filiere
                                                            </label>
                                                            <input type="text" class="form-control form-control-lg"
                                                                name="nom_filiere"
                                                                value="<?= htmlspecialchars($filiere['nom_filiere']) ?>" required>
                                                        </div>

                                                        <div class="mb-4">
                                                            <label class="form-label fw-bold">
                                                                <i class="bi bi-text-paragraph text-primary me-2"></i>
                                                                Description
                                                            </label>
                                                            <textarea type="text" class="form-control form-control-lg"
                                                                name="description"
                                                                value="<?= htmlspecialchars($filiere['description']) ?>" required>
                                                            </textarea>
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer bg-light">
                                                        <button type="button" class="btn btn-outline-secondary"
                                                            data-bs-dismiss="modal">
                                                            <i class="bi bi-x-circle me-2"></i>
                                                            Annuler
                                                        </button>
                                                        <button type="submit" name="update" class="btn btn-ok">
                                                            <i class="bi bi-check-circle me-2"></i>
                                                            Enregistrer
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/sidebar.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

</body>

</html>