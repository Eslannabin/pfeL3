<?php
// Utilisateur_gestion.php

session_start();


// Connexion BDD
$db = new PDO('mysql:host=localhost;dbname=pfe;charset=utf8', 'root', '');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Traitements
$message = '';
$error = '';

// Modification du rôle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_role'])) {
    try {
        $stmt = $db->prepare("UPDATE utilisateurs 
                             SET role = ? 
                             WHERE id = ?");
        $stmt->execute([
            $_POST['new_role'],
            intval($_POST['user_id'])
        ]);
        header('Location: Utilisateur_gestion.php');
        $message = 'Rôle mis à jour avec succès';
    } catch (PDOException $e) {
        header('Location: Utilisateur_gestion.php');
        $error = 'Erreur base de données : ' . $e->getMessage();
    }
}

// Suppression d'un utilisateur
if (isset($_GET['delete'])) {
    try {
        $user_id = intval($_GET['delete']);

        // Supprimer les mémoires liés
        $db->beginTransaction();

        // 1. Supprimer les mémoires
        // $stmt_memoires = $db->prepare("DELETE FROM memoires WHERE id_utilisateur = ?");
        // $stmt_memoires->execute([$user_id]);

        // 2. Supprimer l'utilisateur
        $stmt_user = $db->prepare("DELETE FROM utilisateurs WHERE id = ?");
        $stmt_user->execute([$user_id]);

        $db->commit();
        header('Location: Utilisateur_gestion.php');
        $message = 'Utilisateur et données associées supprimés avec succès';
    } catch (Exception $e) {
        $db->rollBack();
        $error = 'Erreur lors de la suppression : ' . $e->getMessage();
        header('Location: Utilisateur_gestion.php');
    }
}

// Récupération des utilisateurs
$query = $db->query("
    SELECT id, nom, prenom, email, role, 
           DATE_FORMAT(date_inscription, '%d/%m/%Y %H:%i') as date_inscription 
    FROM utilisateurs
    ORDER BY date_inscription DESC
");
$users = $query->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des utilisateurs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/sidebar2.css">
    <link rel="stylesheet" href="css/table_de_gestion.css">
    <link rel="stylesheet" href="css/gestion_des_memoires.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .role-badge {
            font-size: 0.8rem;
            padding: 0.35rem 0.65rem;
        }

        .table-hover tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.03);
        }
    </style>
</head>

<body>
    <header>
        <?php include 'header.html' ?>
    </header>

    <div class="wrapper">

        <?php
        include 'html/Admin_sidebar.html';
        // include 'table_de_gestion_memoires.php';
        ?>

        <div class="main-content">
            <h2 class="mb-4"><i class="fas fa-users-cog me-2"></i>Gestion des utilisateurs</h2>

            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?= $message ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Inscription</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($user['prenom']) . ' ' . htmlspecialchars($user['nom']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td>
                                            <form method="post" class="d-inline">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <select name="new_role" class="form-select form-select-sm"
                                                    onchange="this.form.submit()">
                                                    <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>Utilisateur</option>
                                                    <option value="mod" <?= $user['role'] === 'mod' ? 'selected' : '' ?>>Modérateur</option>
                                                    <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                                                </select>
                                            </form>
                                        </td>
                                        <td><?= $user['date_inscription'] ?></td>
                                        <td>
                                            <a href="?delete=<?= $user['id'] ?>"
                                                class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <a href="ajouterUser.php" class="add-livre">
                <i class="fas fa-plus"></i> Ajouter un Utilisateur
            </a>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/sidebar.js"> </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <!-- <script>
        // Activation des tooltips
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(t => new bootstrap.Tooltip(t));
    </script> -->
</body>

</html>