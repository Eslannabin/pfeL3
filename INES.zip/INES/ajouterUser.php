<?php
// session_start();
require_once 'a1111.php'; // Inclure la connexion à la BDD

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données
    $nom = htmlspecialchars(trim($_POST['nom']));
    $prenom = htmlspecialchars(trim($_POST['prenom']));
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $role = in_array($_POST['role'], ['user', 'mod', 'admin']) ? $_POST['role'] : 'user';

    // Validation
    if (empty($nom)) $errors[] = "Le nom est obligatoire";
    if (empty($prenom)) $errors[] = "Le prénom est obligatoire";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email invalide";
    if (strlen($password) < 8) $errors[] = "Le mot de passe doit contenir au moins 8 caractères";

    // Vérifier si l'email existe déjà
    $checkEmail = $db->prepare("SELECT email FROM utilisateurs WHERE email = ?");
    $checkEmail->execute([$email]);
    if ($checkEmail->fetch()) $errors[] = "Cet email est déjà utilisé";

    if (empty($errors)) {
        try {
            // Hachage du mot de passe
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insertion dans la BDD
            $stmt = $db->prepare("
                INSERT INTO utilisateurs 
                (nom, prenom, email, password_hash, role, date_inscription) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([$nom, $prenom, $email, $hashedPassword, $role]);
            
            $_SESSION['success'] = "Utilisateur ajouté avec succès!";
            header('Location: gestion_utilisateurs.php');
            exit();

        } catch (PDOException $e) {
            $errors[] = "Erreur : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un utilisateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Ajouter un utilisateur</h2>

        <?php if (!empty($errors)) : ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error) : ?>
                    <p><?= htmlspecialchars($error) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="border p-4 rounded bg-light">
            <div class="mb-3">
                <label class="form-label">Nom *</label>
                <input type="text" class="form-control" name="nom" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Prénom *</label>
                <input type="text" class="form-control" name="prenom" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Email *</label>
                <input type="email" class="form-control" name="email" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Mot de passe *</label>
                <input type="password" class="form-control" name="password" required minlength="8">
            </div>

            <div class="mb-3">
                <label class="form-label">Rôle</label>
                <select class="form-select" name="role">
                    <option value="user">Utilisateur</option>
                    <option value="mod">Modérateur</option>
                    <option value="admin">Administrateur</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success">Ajouter</button>
            <a href="gestion_utilisateurs.php" class="btn btn-secondary">Retour</a>
        </form>
    </div>
</body>
</html>