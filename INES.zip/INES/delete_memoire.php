<?php
// Check if delete request is submitted
if (isset($_POST['delete'])) {
    // Get the filiere ID from the form
    $id = $_POST['id'];
    
    // Database connection settings (replace with your credentials)
    $servername = "localhost";
    $username = "your_username";
    $password = "your_password";
    $dbname = "your_database";

    try {
        // Create connection using PDO
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare SQL statement to prevent SQL injection
        $stmt = $conn->prepare("DELETE FROM filieres WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        
        // Execute the query
        $stmt->execute();

        // Redirect to refresh the page and prevent form resubmission
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
        
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    
    // Close connection
    $conn = null;
}
?>