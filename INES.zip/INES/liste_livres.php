<?php
require 'a111.php';

// Fetch all books from database 'livres'
try {
    $stmt = $pdo->query("SELECT * FROM memoires WHERE status != 'en_attente' ORDER BY date_ajout DESC");
    $livres = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching livres: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Listes des Livres</title>

    <!-- Load all CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/sidebar2.css">
    <link rel="stylesheet" href="css/liste_de_memoire.css">
    <link rel="stylesheet" href="style.css">


</head>

<body>
    <header>
        <?php include 'header.html' ?>
    </header>
    <div class="wrapper">
        <?php
        include 'html/Admin_sidebar.html';
        ?>
        <div class="main-content">
            <div class="card" style="width: 100%;">
                <div class="card-body">
                    <div class="card-header">
                        <h1>Liste des Livres</h1>
                        <!-- <i class="fas fa-book"></i> Literature Review
                        <i class="fas fa-chart-bar"></i> Results
                        <i class="fa-regular fa-file-lines"></i>doc -->
                    </div>
                    <?php if (empty($livres)): ?>
                        <div class="alert alert-info">
                            <strong>Info!</strong> Aucun livre trouvé dans le system.
                        </div>
                    <?php else: ?>
                        <!-- AJOUTER UN FILTRE DE RECHERCHE -->
                        <div class="table-responsive">
                            <br>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Livre</th>
                                        <th>Auteur</th>
                                        <th>Categorie</th>
                                        <th>Titre</th>
                                        <th>Année</th>
                                        <th>Date Ajout</th>
                                        <th>Date Edition</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach ($livres as $livre): ?>
                                        <tr>
                                            <?php if ($livre['status'] === 'accepter'): ?>
                                                <td style="border-left: 3px solid rgb(46, 169, 116);"><a href="<?= htmlspecialchars($livre['fichier_pdf']) ?>" class="pdf-link" target="_blank">Voir plus</a></td>
                                            <?php elseif ($livre['status'] === 'refuser'): ?>
                                                <td style="border-left: 3px solid rgb(224, 54, 54);"><a href="<?= htmlspecialchars($livre['fichier_pdf']) ?>" class="pdf-link" target="_blank">Voir plus</a></td>
                                            <?php endif; ?>

                                            <td><?= htmlspecialchars($livre['auteur']) ?></td>
                                            <td><?= htmlspecialchars($livre['titre']) ?></td>
                                            <td><?= htmlspecialchars($livre['annee']) ?></td>
                                            <td><?= htmlspecialchars($livre['date_ajout']) ?></td>
                                            <td><?= htmlspecialchars($livre['date_edition']) ?></td>

                                            <td class="action-buttons">
                                                <?php if ($livre['status'] != 'en_attente'): ?>
                                                    <?php if ($livre['status'] === 'accepter'): ?>
                                                        <input type="hidden" name="memoire_id" value="<?= $livre['id'] ?>">
                                                        <button type="submit" class="btn btn-outline-warning" style="display: inline;">Editer</button>
                                                    <?php endif; ?>
                                                    <form method="post" action="delete_memoire.php" style="display: inline;">
                                                        <input type="hidden" name="memoire_id" value="<?= $livre['id'] ?>">
                                                        <button type="submit" class="btn btn-outline-danger" style="display: inline;">Supprimer</button>
                                                    </form>

                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/sidebar.js"> </script>
</body>

</html>